//
//  ViewController.swift
//  Meditation App
//
//  Created by user on 12.09.2022.
//

import UIKit
import Alamofire
import SwiftyJSON

class SinglnViewController: UIViewController {
    

}

